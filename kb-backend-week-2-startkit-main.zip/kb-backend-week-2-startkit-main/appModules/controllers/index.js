const mainRouteController = require ("./main")
const gameRouteController = require ("./game")
const defaultRouteControlle = require ("./default")
const voteRouteController = require ("./vote")

module.exports = {
 mainRouteController,
 gameRouteController,
 defaultRouteControlle,
 voteRouteController,
}