const {getData, getRandomGame} = require("../api/api-untils")
const endpoints = require("./config")

module.exports = {
    endpoints,
    getData,
    getRandomGame,
};