const {getData, getRandomGame} = require("./api-untils")
const endpoints = require("./config")

module.exports = {
    endpoints,
    getData,
    getRandomGame,
};