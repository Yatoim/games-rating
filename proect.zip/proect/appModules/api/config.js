const BASE_URL = "https://api-code-2.practicum-team.ru";

const endpoints = {
    games: `${BASE_URL}/games`,
};
module.exports = endpoints; 