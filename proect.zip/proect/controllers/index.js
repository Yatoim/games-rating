const gameRouteController = require ("./game")
const defaultRouteController = require ("./default")
const voteRouteController = require ("./vote")
const mainRouteController = require ("./main")
module.exports = {
 mainRouteController,
 gameRouteController,
 defaultRouteController,
 voteRouteController,
}